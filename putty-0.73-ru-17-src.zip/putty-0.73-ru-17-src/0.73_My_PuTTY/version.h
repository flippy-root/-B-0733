#define RELEASE 0.73
#define TEXTVER "Release 0.73"
#define SSHVER "PuTTY-Release-0.73"
#define BINARY_VERSION 0,73,1,17
#define SOURCE_COMMIT "unavailable"
