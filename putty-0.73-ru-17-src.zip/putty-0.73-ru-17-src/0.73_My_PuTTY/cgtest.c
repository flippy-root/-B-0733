/*
 * cgtest.c: stub file to compile cmdgen.c in self-test mode
 */

#define TEST_CMDGEN
#include "cmdgen.c"
