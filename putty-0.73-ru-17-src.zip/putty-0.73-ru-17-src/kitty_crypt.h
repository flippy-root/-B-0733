#ifndef KITTYCRYPT_H
#define KITTYCRYPT_H

#include "nbcrypt.h"

extern char PassKey[1024] ;

int cryptstring( char * st, const char * key ) ;
int decryptstring( char * st, const char * key ) ;

// Generation de la cle privee PuTTY
int GenerePrivateKey( const char * filename ) ;

// Procedure de management de la passphrase
char * ManagePassPhrase( const char * st ) ;

#endif
