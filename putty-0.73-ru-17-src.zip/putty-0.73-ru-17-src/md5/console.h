#ifndef __CONSOLE_H__
  #define __CONSOLE_H__

  extern VOID PrintConsole(LPCTSTR, ...);

#endif

