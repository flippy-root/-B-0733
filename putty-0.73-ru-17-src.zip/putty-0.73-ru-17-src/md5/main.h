#ifndef __MAIN_H__
  #define __MAIN_H__

  extern VOID NORETURN mainCRTStartup(VOID);

#endif

