#include <windows.h>

/* Procedure de verification de la signature */
BOOL CheckMD5Integrity(void) ;
