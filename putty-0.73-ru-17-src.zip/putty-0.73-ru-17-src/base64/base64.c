/*
    Fichier base64.c
    Auteur Bernard Chardonneau
    ameliorations encode64 proposees par big.lol@free.fr

    Logiciel libre, droits d'utilisation precises en francais
    dans le fichier : licence.fr

    Traductions des droits d'utilisation dans les fichiers :
    licence.de , licence.en , licence.es , licence.it
    licence.nl , licence.pt , licence.eo , licence.eo-utf


    Bibliotheque de fonctions permettant d'encoder et de
    decoder le contenu d'un tableau en base64.
*/

#include "base64.h"


/* encode base64 nbcar caracteres memorises
   dans orig et met le resultat dans dest */

void encode64 (char *orig, char *dest, int nbcar)
{
    // groupe de 3 octets a convertir en base 64
    unsigned char octet1, octet2, octet3;

    // tableau d'encodage
    // ce tableau est statique pour eviter une allocation
    // memoire + initialisation a chaque appel de la fonction
    static char   valcar [] =
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";


    // tant qu'il reste au moins 3 caracteres a encoder
    while (nbcar >= 3)
    {
        // extraire 3 caracteres de la chaine et les
        // memoriser sous la forme d'octets (non siges)
        octet1 = *(orig++);
        octet2 = *(orig++);
        octet3 = *(orig++);

        // decomposer les 3 octets en tranches de 6 bits et les
        // remplacer par les caracteres correspondants dans valcar
        *(dest++) = valcar [octet1 >> 2];
        *(dest++) = valcar [((octet1 & 3) << 4) | (octet2 >> 4)];
        *(dest++) = valcar [((octet2 & 0x0F) << 2) | (octet3 >> 6)];
        *(dest++) = valcar [octet3 & 0x3F];

        // 3 caracteres de moins a traiter
        nbcar -= 3;
    }

    // s'il reste des caracteres a encoder
    if (nbcar)
    {
        // encodage des 6 bits de poids fort du premier caractere
        octet1 = *(orig++);
        *(dest++) = valcar [octet1 >> 2];

        // s'il ne reste que ce caractere a encoder
        if (nbcar == 1)
        {
            // encodage des 2 bits de poids faible de ce ce caractere
            *(dest++) = valcar [(octet1 & 3) << 4];

            // indique qu'aucun autre caractere n'est encode
            *(dest++) = '=';
        }
        // sinon (il reste 2 caracteres a encoder)
        else
        {
            // 2 bits de poids faible du 1er caractere + encodage de l'autre
            octet2 = *orig;
            *(dest++) = valcar [((octet1 & 3) << 4) | (octet2 >> 4)];
            *(dest++) = valcar [(octet2 & 0x0F) << 2];
        }

        // indique qu'aucun autre caractere n'est encode
        *(dest++) = '=';
    }

    // fin de l'encodage
    *dest = '\0';
}



/* decode le contenu de buffer encode base64, met le resultat
   dans buffer et retourne le nombre de caracteres convertis */

int decode64 (char *buffer)
{
    int  car;        // caractere du fichier
    char valcar[4]=""; // valeur apres conversion des caracteres
    int  i;          // compteur
    int  posorig;    // position dans la ligne passee en parametre
    int  posdest;    // position dans la nouvelle ligne generee


    // initialisations
    posorig = 0;
    posdest = 0;

    // tant que non fin de ligne
    while (buffer [posorig] > ' ' && buffer [posorig] != '=')
    {
        // decoder la valeur de 4 caracteres
        for (i = 0; i < 4 && buffer [posorig] != '='; i++)
        {
            // recuperer un caractere dans la ligne
            car = buffer [posorig++];

            // decoder ce caractere
            if ('A' <= car && car <= 'Z')
                valcar [i] = car - 'A';
            else if ('a' <= car && car <= 'z')
                valcar [i] = car + 26 - 'a';
            else if ('0' <= car && car <= '9')
                valcar [i] = car + 52 - '0';
            else if (car == '+')
                valcar [i] = 62;
            else if (car == '/')
                valcar [i] = 63;
        }

        // recopier les caracteres correspondants dans le buffer
        buffer [posdest++] = (valcar [0] << 2) | (valcar [1] >> 4);

        // sauf si indicateur de fin de message
        if (i > 2)
        {
            buffer [posdest++] = (valcar [1] << 4) | (valcar [2] >> 2);

            if (i > 3)
                buffer [posdest++] = (valcar [2] << 6) | (valcar [3]);
        }
    }

    // terminer le buffer
    buffer [posdest] = '\0';

    // et retourner le nombre de caracteres obtenus
    return (posdest);
}
